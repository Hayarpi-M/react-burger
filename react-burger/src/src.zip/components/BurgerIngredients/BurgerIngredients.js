import React, { useEffect, useState, useRef } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Tab } from '@ya.praktikum/react-developer-burger-ui-components';
import styles from './BurgerIngredients.module.css';
//import { BASE_URL } from '../../utils/constants';
import Modal from '../Modal/Modal';
import IngredientDetails from '../IngredientDetails/IngredientDetails';
import IngredientCard from './IngredientCard/IngredientCard';
/**/import IngredientSection from './IngredientSection/IngredientSection';
import { getIngredients } from '../../services/actions/BurgerIngredients';

const BurgerIngredients = () => {
    const dispatch = useDispatch();
    const { items, itemsRequest, itemsFailed } = useSelector((state) => state.ingredients);

    const [current, setCurrent] = useState('bun');
    const [selectedIngredient, setSelectedIngredient] = useState(null);

    /*const [data, setData] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [hasError, setHasError] = useState(false);
    const handleIngredientClick = (ingredient) => {
        setSelectedIngredient(ingredient);
    };
    const closeModal = () => {
        setSelectedIngredient(null);
    };*/
    const bunRef = useRef(null);
    const sauceRef = useRef(null);
    const mainRef = useRef(null);

    const handleTabClick = (section) => {
        setCurrent(section);
        if(section === "bun") bunRef.current.scrollIntoView({ behavior: 'smooth' });
        if(section === "sauce") sauceRef.current.scrollIntoView({ behavior: 'smooth' });
        if(section === "main") mainRef.current.scrollIntoView({ behavior: 'smooth' });
    }

    useEffect(() => {
        dispatch(getIngredients());
    }, [dispatch]);

    const handleIngredientClick = (ingredient) => {
        setSelectedIngredient(ingredient);
    };

    const closeModal = () => {
        setSelectedIngredient(null);
    };

    const filteredIngredients = (type) =>
        (items || []).filter((item) => item.type === type);

    /*const getIngredients = async () => {
        itemsRequest(true);
        itemsFailed(false);
        try {
        //const res = await fetch('https://norma.nomoreparties.space/api/ingredients');
        const res = await fetch(`${BASE_URL}/ingredients`);
        const json = await res.json();
        setData(json.data);
        } catch (e) {
        setHasError(true);
        } finally {
        setIsLoading(false);
        }
    };*/
    
    if (itemsRequest) return <p>Loading...</p>;
    if (itemsFailed) return <p>Ошибка загрузки ингредиентов</p>;

    return (
        <section className={styles.containerIngred}>

            <div style={{ display: 'flex' }} className="mb-10">
                <Tab value="bun" active={current === 'bun'} onClick={handleTabClick}>
                    Булки
                </Tab>
                <Tab value="sauce" active={current === 'sauce'} onClick={handleTabClick}>
                    Соусы
                </Tab>
                <Tab value="main" active={current === 'main'} onClick={handleTabClick}>
                    Начинки
                </Tab>
            </div>

            <div className={styles.scrollY}>
                    <>
                        <IngredientSection
                            title="Булки"
                            items={filteredIngredients('bun')}
                            sectionRef={bunRef}
                            onClick={handleIngredientClick}
                            draggable
                        />
                    </>
                    <>
                        <IngredientSection
                            title="Соусы"
                            items={filteredIngredients('sauce')}
                            sectionRef={sauceRef}
                            onClick={handleIngredientClick}
                            draggable
                        />
                    </>
                    <>
                        <IngredientSection
                            title="Начинки"
                            items={filteredIngredients('main')}
                            sectionRef={mainRef}
                            onClick={handleIngredientClick}
                            draggable
                        />
                    </>
            </div>
            {selectedIngredient && (
                <Modal title="Детали ингредиента" onClose={closeModal}>
                   
                    <IngredientDetails ingredient={selectedIngredient} />
                </Modal>
            )}
        </section>
    );
};

export default BurgerIngredients;












