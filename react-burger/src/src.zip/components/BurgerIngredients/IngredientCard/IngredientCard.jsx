import React from 'react';
import { useDrag } from 'react-dnd';
import PropTypes from 'prop-types';
import { CurrencyIcon, Counter } from '@ya.praktikum/react-developer-burger-ui-components';
import stylesIngredientCard from './IngredientCard.module.css';
import { v4 as uuidv4 } from 'uuid';



const IngredientCard = ({ item, onClick }) => {
    const [{ isDragging }, dragRef] = useDrag({
    type: 'ingredient', // This must match the 'accept' in BurgerConstructor
    item: { ...item, uuid: uuidv4() }, // Add uuid for tracking uniqueness
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });
    return (
        <div ref={dragRef} onClick={() => {onClick(item)}} className={stylesIngredientCard.IngredientCardWrapper}>
            <Counter count={1} size="default" />
            <img src={item.image} alt={item.name} className="ml-4 mr-4" />
            <div className= {`mt-1 mb-1 ${stylesIngredientCard.priceWrapper}`}>
                <span className="text text_type_digits-default mr-2">{item.price}</span>
                <CurrencyIcon type="primary" />
            </div>
            <p className="text text_type_main-default">{item.name}</p>
        </div>
    );
};

IngredientCard.propTypes = {
    item: PropTypes.shape({
      _id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      image: PropTypes.string.isRequired,
      price: PropTypes.number.isRequired,
      type: PropTypes.string.isRequired,
    }).isRequired,
    onClick: PropTypes.func.isRequired,
};
  

export default IngredientCard;