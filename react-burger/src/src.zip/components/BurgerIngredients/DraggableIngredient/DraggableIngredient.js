import React from 'react';
import { useDrag } from 'react-dnd';
import PropTypes from 'prop-types';
import IngredientCard from '../IngredientCard/IngredientCard';

const DraggableIngredient = ({ item, onClick }) => {
  const [, dragRef] = useDrag({
    type: 'ingredient',
    item,
  });

  return (
    <div ref={dragRef}>
      <IngredientCard item={item} onClick={onClick} />
    </div>
  );
};

DraggableIngredient.propTypes = {
  item: PropTypes.shape({
    _id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    image: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    type: PropTypes.string.isRequired,
  }).isRequired,
  onClick: PropTypes.func.isRequired,
};

export default DraggableIngredient;
