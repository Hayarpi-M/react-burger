/*import { useState} from 'react';
import PropTypes from 'prop-types';
import styles from './BurgerConstructor.module.css';
import OrderDetails from '../OrderDetails/OrderDetails';
import Modal from '../Modal/Modal';
import { ConstructorElement, DragIcon, CurrencyIcon, Button } from '@ya.praktikum/react-developer-burger-ui-components';*/

import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useDrop } from 'react-dnd';
import { addIngredient, reorderIngredients } from '../../services/actions/BurgerConstructor';
import ConstructorItem from './ConstructorItem/ConstructorItem'; // You create this
import BunPreview from './BunPreview/BunPreview'; // You create this
import update from 'immutability-helper';

const BurgerConstructor = () => {
  const dispatch = useDispatch();
  const { bun, ingredients = [] } = useSelector((state) => state.constructor);


  const [{ isOver }, dropRef] = useDrop({
    accept: ['ingredient', 'sort'],
    drop(item) {
      console.log('Dropped item:', item); 
      dispatch(addIngredient(item));
    },
  });

  const moveIngredient = (dragIndex, hoverIndex) => {
    const newOrder = update(ingredients, {
      $splice: [
        [dragIndex, 1],
        [hoverIndex, 0, ingredients[dragIndex]],
      ],
    });
    dispatch(reorderIngredients(newOrder));
  };
  

  return (
    <div ref={dropRef} style={{ border: isOver ? '2px dashed green' : 'none' }}>
      {bun && <BunPreview type="top" bun={bun} />}
      {ingredients.map((item, index) => (
        <ConstructorItem
          key={item.uuid}
          item={item}
          index={index}
          moveIngredient={moveIngredient}
        />
      ))}
      {bun && <BunPreview type="bottom" bun={bun} />}
    </div>
  );
};

export default BurgerConstructor;